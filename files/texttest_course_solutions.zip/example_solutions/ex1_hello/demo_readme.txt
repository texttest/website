1. Run hello.py from the command line. Explain that we're testing this behaviour.
2. texttest --new
3. Fill in form. Discuss purpose of file extension. Point out "subdirectory" setting and tell everyone to use it for all exercises.
4. Run Test. Explain why it's red. Approve it.
5. Show Config tab and generated config file briefly. Explain difference between personal and application files.
