#!/usr/bin/env python

import urllib
from HTMLParser import HTMLParser, HTMLParseError

def get_attr_value(attrs, name):
    for attr, val in attrs:
        if attr == name:
            return val

class TimeHtmlParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.text = ""
        self.inContext = False

    def handle_starttag(self, rawname, attrs):
        name = rawname.lower()
        if name == "div" and get_attr_value(attrs, "id") == "time":
            self.inContext = True

    def handle_data(self, content):
        if self.inContext and content.strip():
            self.text = content.strip()
            self.inContext = False

for timezone in [ "UTC", "SE" ]:
    text = urllib.urlopen("http://www.worldtimeserver.com/current_time_in_" + timezone + ".aspx").read()
    parser = TimeHtmlParser()
    parser.feed(text)
    print timezone.rjust(3), "=", parser.text
