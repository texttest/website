1. Go to directory in shell. Run current_time_system.py. Say what it does and look at the code briefly: we're just repackaging "date"
2. texttest --new
3. Fill in form. Enable CaptureMock checkbox. Locate program.
4. Create test, run it, approve it. Point out that it fail a minute later. Point out that filtering isn't appropriate.
5. Select root suite, Definition Files, right click, Create/Import. Choose capturemockrc. Add the contents

[command line]
intercepts = date

Explain what this does: i.e. captures the behaviour of "date".

6. Run the test in record mode. Explain what has happened, look at the externalmocks file and explain the syntax.
7. Run in replay mode, point out green when time is different.
8. From command line, run current_time_online.py. Look in the code, point out the use of urllib module for screenscraping.
Possibly show the webpage that it's scraping 
http://www.worldtimeserver.com/current_time_in_SE.aspx
but maybe best to install Flashblock first! It seems to produce adverts of "beautiful Chinese ladies" quite a lot, which may distract/offend the audience :)
9. Create a version for this code. Open config file in emacs, save as config.<app>.online, remove everything except executable, change "system" to "online".
10. Run the version. Note the previous intercept doesn't help.
11. Go back to capturemockrc. Add the lines

[python]
intercepts = urllib

to prove we can do the same inside Python.
12. Run in record mode as before. Look at generate pythonmocks file, explain the first few lines, don't worry about all the HTML after that.
13. Use "Approve As" to save these files as the version "online".
14. Add "extra_version:online" to the config file, explaining what it does: making this version of the tests included and rerun automatically.
Restart TextTest and illustrate how that looks. Run both versions and ensure they are green.

