#!/usr/bin/env python

import sys, os, time
from fnmatch import fnmatch
from filecmp import cmp

def localtime(format= "%d%b%H:%M:%S", seconds=None):
    if not seconds:
        seconds = time.time()
    return time.strftime(format, time.localtime(seconds))

def searchAndReplace(toFind, toReplace, pattern):
    print "searchreplace.py running at", localtime()
    print "Replacing '" + toFind + "' with '" + toReplace + "'"
    for root, dirs, files in os.walk(os.getcwd()):
        for file in files:
            if fnmatch(file, pattern):
                fileName = os.path.join(root, file)
                if not os.path.isfile(fileName):
                    continue
                print "Replacing in", fileName
                newFileName = fileName + ".new"
                try:
                    newFile = open(newFileName, "w")
                except IOError:
                    print "No permission to edit, continuing"
                    continue
                for line in open(fileName).xreadlines():
                    newFile.write(line.replace(toFind, toReplace))
                newFile.close()
                if not cmp(fileName, newFileName, 0):
                    os.system("diff " + fileName + " " + newFileName)
                    print "OK to commit?"
                    answer = sys.stdin.readline().strip()
                    if answer == "y":
                        os.remove(fileName)
                        os.rename(newFileName, fileName)
                    else:
                        os.remove(newFileName)
                        print "Not editing the file."
                        break
                else:
                    os.remove(newFileName)

if len(sys.argv) < 4:
    print "Usage : searchreplace.py <toFind> <toReplace> <files>"
else:
    toFind = sys.argv[1]
    toReplace = sys.argv[2].replace("\\n", "\n")
    pattern = sys.argv[3]
    searchAndReplace(toFind, toReplace, pattern)

