
class SMTP:
    def connect(self, host):
        print "Connecting to", host
    def sendmail(self, fromAddr, toAddr, mailContents):
        print "Sending mail from", fromAddr, "to", toAddr, ":"
        print mailContents.strip()
    def quit(self):
        print "Quitting"
