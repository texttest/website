1. Start GUI (videostore.py). Explain that it's standard and hasn't been adapted for TextTest.
2. texttest --new
3. Fill in form. Select GUI option (PyGTK). Locate program.
4. Create test, called AddMovie. Record Use-Case. Explain briefly what's going on.
5. Enter "Star Wars", press "Add". Close Video Store.
6. Explain point of StoryText Editor dialog. Enter names, such as "set movie name to", "add movie", "close".
7. Approve and close in TT. Explain why TT replay run happens. Explain why GUI isn't visible in replay (Xvfb).
8. Approve again. Possibly run again and show green.
9. Run again with GUI visible and a delay present so people can see the GUI is really run.
10. Add new test, "SortMovies".
11. Record again. "Star Wars", Add, "Die Hard", Add, Sort, Close.
12. Explain why StoryText Editor is now mostly full. Building up language etc. Enter name "sort movies".
13. Before closing, add a shortcut for the typing in a name and adding it. Call it e.g. "add new movie". Explain what it's for. Point out that it gets applied to both examples.
14. Run both tests and note the shortcut gets inserted into the first test now.
15. Show Config tab and generated UI map file and shortcut file briefly. 
