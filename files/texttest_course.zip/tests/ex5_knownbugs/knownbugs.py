import sys, random

def printMessage(message):
    print message

if __name__ == "__main__":
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg == "fail":
            printMessage("Hello world!!!")
        elif arg == "multifail":
            printMessage("Hello")
            raise Exception("Error while saying hello to the world")
        elif arg == "random":
            random.seed()
            if random.random() < 0.7:
                printMessage("Hello world")
    else:
        printMessage("Hello world")
