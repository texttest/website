#!/usr/bin/env python

import subprocess

def get_output(args):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return p.communicate()[0].strip()

def add_one_hour(utc):
    parts = utc.split(":")
    hour = int(parts[0].strip())
    newHour = (hour % 12) + 1
    hourStr = str(newHour)
    return ":".join([hourStr, parts[1]])

utc = get_output([ "date", "-u", "+%l:%M %p" ])
print "UTC = " + utc
print " GB = " + add_one_hour(utc)
print " PL = " + get_output([ "date", "+%l:%M %p" ])
