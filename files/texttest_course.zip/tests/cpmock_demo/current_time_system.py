#!/usr/bin/env python

import subprocess

def get_output(args):
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return p.communicate()[0].strip()

utc = get_output([ "date", "-u", "+%l:%M %p" ])
print "UTC = " + utc
print " SE = " + get_output([ "date", "+%l:%M %p" ])
