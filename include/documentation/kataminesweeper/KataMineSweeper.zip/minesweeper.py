import sys
def log(message):
    print >> sys.stderr, message

MINE = "*"
END_OF_INPUT = "0 0"

class Minefield:
    def __init__(self, m, n, minefield):
        self.m = m
        self.n = n
        self.minefield = minefield

    def clues_to_str(self, clues):
        clues_str = ""
        for i in range(self.m):
            for j in range(self.n):
                clues_str += str(clues[(i, j)])
            clues_str += "\n"
        return clues_str

    def clues(self):
        clues = dict.fromkeys([ (x, y) for x in range(self.m)\
                                          for y in range(self.n)], 0)
        log("initialized clues dictionary %s" % clues)
        for x, row in enumerate(self.minefield.splitlines()):
            for y, cell in enumerate(row):
                if cell == MINE:
                    clues[ (x, y) ] = MINE
                    self.increment_adjacent(clues, x, y)
        log("calculated clues %s" % clues)
        clues_str = self.clues_to_str(clues)
        return clues_str

    def increment_adjacent(self, clues, x, y):
        for i in (x-1, x, x+1):
            for j in (y-1, y, y+1):
                if clues.get( (i, j) ) not in [None, MINE]:
                    clues[ (i, j) ] += 1

def MinefieldReader(inputfile):
    next = iter(inputfile).next
    while 1:
        shape = next().strip()
        if shape == END_OF_INPUT:
            raise StopIteration()
        m, n = map(int, shape.split())
        log("found minefield shape %s %s" % (m, n))
        minefield = ""
        for i in range(m):
            minefield += next()
        yield m, n, minefield

def main(inputfile, outputfile):
    counter = 0
    for m, n, minefield in MinefieldReader(inputfile):
        counter += 1
        print >> outputfile, "Field #%d:" % counter
        print >> outputfile, Minefield(m, n, minefield).clues()

if __name__ == "__main__":
    inputfile = sys.stdin
    outputfile = sys.stdout
    main(inputfile, outputfile)